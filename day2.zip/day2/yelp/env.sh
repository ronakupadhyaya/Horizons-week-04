export MONGODB_URI=mongodb://neil:perr@ds133192.mlab.com:33192/yelpneil
#export MONGODB_URI=mongodb://localhost:27017/yelpneil