# Day 2 Exercises

## Morning Videos & Individual Exercises

1. [Advanced Mongoose Videos and Exercises Part 1](examples/part1/)
1. [Advanced Mongoose Videos and Exercises Part 2](examples/part2/)

## Pair programming exercise

1. [Yelp!](yelp/)
