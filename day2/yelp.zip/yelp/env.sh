MONGODB_URI=mongodb://1:1@ds133582.mlab.com:33582/yelp_shenchenhui

export MONGODB_URI;
